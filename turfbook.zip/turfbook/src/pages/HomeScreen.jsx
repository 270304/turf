import { useState } from 'react'
import { Search, SlidersHorizontal, Bell } from 'lucide-react'
import { TURFS, SPORTS } from '../data/turfs.js'
import TurfCard from '../components/TurfCard.jsx'

const FILTERS = ['Open now', 'Under 2 km', 'Under ₹500/hr', 'Indoor', 'Floodlit']

export default function HomeScreen({ onTurfClick }) {
  const [activeSport, setActiveSport] = useState('all')
  const [query, setQuery] = useState('')
  const [activeFilters, setActiveFilters] = useState(['Open now'])

  const toggleFilter = (f) =>
    setActiveFilters(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f])

  const filtered = TURFS.filter(t => {
    const matchSport = activeSport === 'all' || t.sports.map(s => s.toLowerCase()).includes(activeSport)
    const matchQ = !query || t.name.toLowerCase().includes(query.toLowerCase()) || t.address.toLowerCase().includes(query.toLowerCase())
    return matchSport && matchQ
  })

  return (
    <>
      {/* Topbar */}
      <header className="topbar" style={{ height: 'auto', padding: '10px 16px 12px', display: 'block', borderBottom: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>TurfBook</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1 }}>📍 Mumbai, Andheri</div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-2)' }} aria-label="Notifications">
              <Bell size={20} />
            </button>
            <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--accent-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, color: 'var(--accent-mid)' }}>
              A
            </div>
          </div>
        </div>
        <div className="search-wrap" style={{ margin: 0 }}>
          <Search size={16} color="var(--text-3)" aria-hidden="true" />
          <input
            type="text"
            placeholder="Search turfs, areas..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            aria-label="Search turfs"
          />
          <SlidersHorizontal size={16} color="var(--text-3)" aria-label="Filters" />
        </div>
      </header>

      {/* Sport chips */}
      <div className="sport-scroll" role="group" aria-label="Filter by sport">
        {SPORTS.map(s => (
          <button
            key={s.id}
            className={`sport-chip${activeSport === s.id ? ' active' : ''}`}
            onClick={() => setActiveSport(s.id)}
            aria-pressed={activeSport === s.id}
          >
            <div className="sport-icon-wrap">
              <span role="img" aria-label={s.label}>{s.emoji}</span>
            </div>
            <span className="sport-chip-label">{s.label}</span>
          </button>
        ))}
      </div>

      {/* Filter pills */}
      <div className="filter-row" role="group" aria-label="Quick filters">
        {FILTERS.map(f => (
          <button
            key={f}
            className={`filter-pill${activeFilters.includes(f) ? ' on' : ''}`}
            onClick={() => toggleFilter(f)}
            aria-pressed={activeFilters.includes(f)}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Turf list */}
      <div className="section-head">
        <span className="section-title">Nearby turfs</span>
        <span className="see-all">{filtered.length} found</span>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">🏟️</div>
          <div className="empty-text">No turfs found.<br />Try a different sport or clear filters.</div>
        </div>
      ) : (
        filtered.map(t => <TurfCard key={t.id} turf={t} onClick={onTurfClick} />)
      )}
    </>
  )
}
