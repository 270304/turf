import { Calendar } from 'lucide-react'

export default function MyBookings({ bookings }) {
  return (
    <>
      <header className="topbar">
        <span className="topbar-title">My bookings</span>
      </header>

      {bookings.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon"><Calendar size={40} color="var(--text-3)" /></div>
          <div className="empty-text">No bookings yet.<br />Find a turf and book your first slot!</div>
        </div>
      ) : (
        <div style={{ padding: '12px 0' }}>
          {bookings.map(b => (
            <div key={b.id} className="booking-card">
              <div className="booking-header">
                <div>
                  <div className="booking-name">{b.turf.name}</div>
                  <div className="booking-meta">{b.date} · {b.slot}</div>
                  <div className="booking-meta">{b.members} players · {b.sport}</div>
                </div>
                <span className={`status-badge status-${b.status}`}>
                  {b.status.charAt(0).toUpperCase() + b.status.slice(1)}
                </span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 8, borderTop: '1px solid var(--border)' }}>
                <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Booking ID: {b.id}</span>
                <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--accent-mid)' }}>₹{b.price}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  )
}
