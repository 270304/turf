import TurfCard from '../components/TurfCard.jsx'
import { TURFS } from '../data/turfs.js'
import { Map } from 'lucide-react'

export default function ExploreScreen({ onTurfClick }) {
  return (
    <>
      <header className="topbar">
        <span className="topbar-title">Explore</span>
      </header>

      {/* Map placeholder — replace with Google Maps or Leaflet */}
      <div className="map-placeholder">
        <Map size={36} color="var(--text-3)" aria-hidden="true" />
        <p>Map view (integrate Google Maps API)</p>
        <p style={{ fontSize: 11 }}>Pass VITE_GOOGLE_MAPS_KEY in .env</p>
      </div>

      <div className="section-head">
        <span className="section-title">All turfs</span>
        <span className="see-all">{TURFS.length} total</span>
      </div>

      {TURFS.map(t => <TurfCard key={t.id} turf={t} onClick={onTurfClick} />)}
    </>
  )
}
