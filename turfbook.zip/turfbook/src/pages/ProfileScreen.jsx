import { User, ChevronRight, Building2, HelpCircle, LogOut } from 'lucide-react'

const menuItems = [
  { icon: Building2, label: 'Register your turf', sub: 'List your turf on TurfBook', action: 'owner' },
  { icon: HelpCircle, label: 'Help & support', sub: 'FAQs and contact us', action: null },
  { icon: LogOut, label: 'Sign out', sub: null, action: null, danger: true },
]

export default function ProfileScreen({ onOwnerPortal }) {
  const handleAction = (action) => {
    if (action === 'owner') onOwnerPortal()
  }

  return (
    <>
      <header className="topbar">
        <span className="topbar-title">Profile</span>
      </header>

      {/* Avatar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '20px 16px 16px' }}>
        <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'var(--accent-light)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 700, color: 'var(--accent-mid)' }}>
          A
        </div>
        <div>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--text)' }}>Aditya</div>
          <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Mumbai, Maharashtra</div>
        </div>
      </div>

      <div style={{ height: 1, background: 'var(--border)', margin: '0 16px 12px' }} />

      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, padding: '0 16px 16px' }}>
        {[['0', 'Bookings'], ['0', 'Reviews'], ['4.9', 'Rating']].map(([val, label]) => (
          <div key={label} style={{ background: 'var(--surface-1)', borderRadius: 12, padding: '12px 8px', textAlign: 'center' }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>{val}</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, margin: '0 16px', overflow: 'hidden' }}>
        {menuItems.map((item, i) => (
          <button
            key={item.label}
            onClick={() => handleAction(item.action)}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              padding: '13px 14px',
              borderTop: i > 0 ? '1px solid var(--border)' : 'none',
              background: 'none',
              border: 'none',
              borderTop: i > 0 ? '1px solid var(--border)' : 'none',
              cursor: 'pointer',
              textAlign: 'left',
            }}
          >
            <item.icon size={20} color={item.danger ? 'var(--danger)' : 'var(--text-2)'} aria-hidden="true" />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500, color: item.danger ? 'var(--danger)' : 'var(--text)' }}>{item.label}</div>
              {item.sub && <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1 }}>{item.sub}</div>}
            </div>
            {!item.danger && <ChevronRight size={16} color="var(--text-3)" aria-hidden="true" />}
          </button>
        ))}
      </div>
    </>
  )
}
