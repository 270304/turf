import { CheckCircle } from 'lucide-react'

export default function SuccessScreen({ booking, onHome }) {
  if (!booking) return null

  return (
    <>
      <div className="success-icon">
        <CheckCircle size={40} color="var(--success)" aria-hidden="true" />
      </div>
      <div className="success-title">Booking confirmed!</div>
      <div className="success-sub">
        Your slot at {booking.turf.name} on {booking.date} at {booking.slot} is reserved.
      </div>

      <div className="summary-card">
        {[
          { label: 'Booking ID', val: booking.id },
          { label: 'Turf', val: booking.turf.name },
          { label: 'Date', val: booking.date },
          { label: 'Time', val: booking.slot },
          { label: 'Players', val: `${booking.members} players` },
          { label: 'Sport', val: booking.sport },
          { label: 'Amount paid', val: `₹${booking.price}` },
        ].map(r => (
          <div key={r.label} className="summary-row">
            <span className="summary-label">{r.label}</span>
            <span className="summary-val" style={r.label === 'Amount paid' ? { color: 'var(--accent-mid)', fontWeight: 700 } : {}}>{r.val}</span>
          </div>
        ))}
      </div>

      <div style={{ padding: '0 16px 12px' }}>
        <div style={{ background: 'var(--success-light)', borderRadius: 10, padding: '12px 14px', fontSize: 13, color: 'var(--success)', lineHeight: 1.6 }}>
          ✅ A confirmation has been sent to your registered number. Show your booking ID at the turf entrance.
        </div>
      </div>

      <div className="cta-bar">
        <button className="cta-btn success-btn" onClick={onHome}>
          Back to home
        </button>
      </div>
    </>
  )
}
