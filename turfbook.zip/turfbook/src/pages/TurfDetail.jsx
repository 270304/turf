import { useState } from 'react'
import { ArrowLeft, MapPin, Clock, Users, ChevronRight } from 'lucide-react'
import { DATES, REVIEWS } from '../data/turfs.js'
import Stars from '../components/Stars.jsx'

export default function TurfDetail({ turf, onBack, onContinue }) {
  const [selectedDate, setSelectedDate] = useState(0)
  const [selectedSlot, setSelectedSlot] = useState(null)
  const [members, setMembers] = useState(turf.minPlayers)

  const handleContinue = () => {
    if (selectedSlot === null) return
    onContinue({
      date: DATES[selectedDate],
      slot: turf.slots[selectedSlot].time,
      members,
      price: turf.price,
      sport: turf.sports[0],
    })
  }

  return (
    <>
      <header className="topbar">
        <button className="back-btn" onClick={onBack} aria-label="Go back">
          <ArrowLeft size={20} />
        </button>
        <span className="topbar-title">{turf.name}</span>
      </header>

      {/* Hero image */}
      <div style={{ width: '100%', height: 180, background: turf.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 64 }}>
        <span role="img" aria-hidden="true">{turf.emoji}</span>
      </div>

      {/* Info */}
      <div style={{ padding: '12px 16px 8px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--text)' }}>{turf.name}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 3, color: 'var(--text-3)', fontSize: 13 }}>
              <MapPin size={12} aria-hidden="true" /> {turf.address} · {turf.dist} km away
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 5 }}>
              <Stars rating={turf.rating} />
              <span style={{ fontSize: 13, color: 'var(--text-2)' }}>{turf.rating} ({turf.reviewCount} reviews)</span>
            </div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0, marginLeft: 12 }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>₹{turf.price}</div>
            <div style={{ fontSize: 11, color: 'var(--text-3)' }}>per hour</div>
          </div>
        </div>

        {/* Sport tags */}
        <div className="sport-tags" style={{ marginTop: 10 }}>
          {turf.sports.map(s => <span key={s} className="sport-tag">{s}</span>)}
        </div>

        {/* Open hours */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, marginTop: 10, fontSize: 13, color: 'var(--text-2)' }}>
          <Clock size={13} aria-hidden="true" />
          <span>{turf.open}</span>
          <span style={{ marginLeft: 4, background: 'var(--success-light)', color: 'var(--success)', fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 20 }}>Open</span>
        </div>
      </div>

      {/* Amenities */}
      <div style={{ padding: '4px 16px 0', fontSize: 13, fontWeight: 600, color: 'var(--text-2)' }}>Amenities</div>
      <div className="amenity-wrap">
        {turf.amenities.map(a => <span key={a} className="amenity-chip">{a}</span>)}
      </div>

      <div style={{ height: 1, background: 'var(--border)', margin: '0 16px' }} />

      {/* Date picker */}
      <div style={{ padding: '12px 16px 4px', fontSize: 13, fontWeight: 600, color: 'var(--text-2)' }}>Pick a date</div>
      <div className="date-scroll">
        {DATES.map((d, i) => (
          <button
            key={d}
            className={`date-chip${selectedDate === i ? ' selected' : ''}`}
            onClick={() => { setSelectedDate(i); setSelectedSlot(null) }}
            aria-pressed={selectedDate === i}
          >
            {d}
          </button>
        ))}
      </div>

      {/* Slot grid */}
      <div style={{ padding: '10px 16px 6px', fontSize: 13, fontWeight: 600, color: 'var(--text-2)' }}>Available slots</div>
      <div className="slot-grid" role="group" aria-label="Time slots">
        {turf.slots.map((s, i) => (
          <div
            key={i}
            className={`slot${s.booked ? ' booked' : ''}${selectedSlot === i && !s.booked ? ' selected' : ''}`}
            onClick={() => !s.booked && setSelectedSlot(i)}
            role="button"
            tabIndex={s.booked ? -1 : 0}
            aria-pressed={selectedSlot === i}
            aria-label={`${s.time} ${s.booked ? '– unavailable' : ''}`}
            onKeyDown={e => e.key === 'Enter' && !s.booked && setSelectedSlot(i)}
          >
            <div className="slot-time">{s.time}</div>
            <div className="slot-status">{s.booked ? 'Booked' : 'Available'}</div>
          </div>
        ))}
      </div>

      {/* Member stepper */}
      <div className="member-row">
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text)', display: 'flex', alignItems: 'center', gap: 5 }}>
            <Users size={15} aria-hidden="true" /> Players
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>
            Min {turf.minPlayers} · Max {turf.maxPlayers}
          </div>
        </div>
        <div className="stepper">
          <button
            className="step-btn"
            onClick={() => setMembers(m => Math.max(turf.minPlayers, m - 1))}
            disabled={members <= turf.minPlayers}
            aria-label="Remove player"
          >−</button>
          <span className="step-val" aria-live="polite">{members}</span>
          <button
            className="step-btn"
            onClick={() => setMembers(m => Math.min(turf.maxPlayers, m + 1))}
            disabled={members >= turf.maxPlayers}
            aria-label="Add player"
          >+</button>
        </div>
      </div>

      {/* Reviews */}
      <div style={{ padding: '14px 16px 6px', fontSize: 13, fontWeight: 600, color: 'var(--text-2)' }}>
        Reviews ({turf.reviewCount})
      </div>
      {REVIEWS.slice(0, 3).map((r, i) => (
        <div key={i} className="review-card">
          <div className="reviewer-row">
            <span className="reviewer-name">{r.user}</span>
            <Stars rating={r.rating} size={11} />
          </div>
          <div className="review-text">{r.text}</div>
        </div>
      ))}

      {/* CTA */}
      <div className="cta-bar">
        <button
          className="cta-btn"
          onClick={handleContinue}
          disabled={selectedSlot === null}
          aria-disabled={selectedSlot === null}
        >
          {selectedSlot === null ? 'Select a slot to continue' : `Continue · ₹${turf.price}`}
        </button>
      </div>
    </>
  )
}
