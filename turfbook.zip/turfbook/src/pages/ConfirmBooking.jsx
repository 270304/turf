import { ArrowLeft } from 'lucide-react'

const QR_SVG = (
  <svg width="110" height="110" viewBox="0 0 110 110" role="img" aria-label="UPI QR code placeholder" xmlns="http://www.w3.org/2000/svg">
    <rect x="4" y="4" width="36" height="36" rx="3" fill="none" stroke="#333" strokeWidth="2.5"/>
    <rect x="12" y="12" width="20" height="20" rx="1" fill="#333"/>
    <rect x="70" y="4" width="36" height="36" rx="3" fill="none" stroke="#333" strokeWidth="2.5"/>
    <rect x="78" y="12" width="20" height="20" rx="1" fill="#333"/>
    <rect x="4" y="70" width="36" height="36" rx="3" fill="none" stroke="#333" strokeWidth="2.5"/>
    <rect x="12" y="78" width="20" height="20" rx="1" fill="#333"/>
    <rect x="48" y="4" width="8" height="8" rx="1" fill="#333"/>
    <rect x="58" y="4" width="8" height="8" rx="1" fill="#333"/>
    <rect x="48" y="14" width="8" height="8" rx="1" fill="#333"/>
    <rect x="48" y="48" width="8" height="8" rx="1" fill="#333"/>
    <rect x="58" y="58" width="8" height="8" rx="1" fill="#333"/>
    <rect x="70" y="48" width="8" height="8" rx="1" fill="#333"/>
    <rect x="80" y="48" width="8" height="8" rx="1" fill="#333"/>
    <rect x="70" y="58" width="8" height="8" rx="1" fill="#333"/>
    <rect x="48" y="70" width="8" height="8" rx="1" fill="#333"/>
    <rect x="58" y="80" width="8" height="8" rx="1" fill="#333"/>
    <rect x="80" y="70" width="8" height="8" rx="1" fill="#333"/>
    <rect x="90" y="80" width="8" height="8" rx="1" fill="#333"/>
    <rect x="48" y="80" width="8" height="8" rx="1" fill="#333"/>
    <rect x="58" y="70" width="8" height="8" rx="1" fill="#333"/>
    <rect x="80" y="90" width="16" height="8" rx="1" fill="#333"/>
    <rect x="48" y="90" width="8" height="8" rx="1" fill="#333"/>
  </svg>
)

export default function ConfirmBooking({ data, onBack, onConfirm }) {
  const { turf, date, slot, members, price, sport } = data

  const rows = [
    { label: 'Turf',     val: turf.name },
    { label: 'Sport',    val: sport },
    { label: 'Date',     val: date },
    { label: 'Slot',     val: slot },
    { label: 'Players',  val: `${members} players` },
    { label: 'Duration', val: '1 hour' },
  ]

  return (
    <>
      <header className="topbar">
        <button className="back-btn" onClick={onBack} aria-label="Go back">
          <ArrowLeft size={20} />
        </button>
        <span className="topbar-title">Confirm booking</span>
      </header>

      {/* Summary */}
      <div className="summary-card">
        {rows.map(r => (
          <div key={r.label} className="summary-row">
            <span className="summary-label">{r.label}</span>
            <span className="summary-val">{r.val}</span>
          </div>
        ))}
        <div className="summary-row summary-total">
          <span className="summary-label">Total</span>
          <span className="summary-val">₹{price}</span>
        </div>
      </div>

      {/* UPI QR */}
      <div style={{ padding: '4px 16px 8px', fontSize: 13, fontWeight: 600, color: 'var(--text-2)' }}>
        Pay via UPI
      </div>
      <div className="upi-box">
        <div style={{ fontSize: 14, color: 'var(--text-2)' }}>Scan QR to pay</div>
        <div className="qr-placeholder">{QR_SVG}</div>
        <div className="upi-id-text">turfbook@upi</div>
        <div className="upi-amount">₹{price}</div>
        <div style={{ marginTop: 12, fontSize: 12, color: 'var(--text-3)', lineHeight: 1.6 }}>
          After payment, tap the button below to confirm your booking. Your slot will be reserved for 10 minutes.
        </div>
      </div>

      <div style={{ height: 16 }} />

      <div className="cta-bar">
        <button className="cta-btn" onClick={onConfirm}>
          I've paid — confirm booking
        </button>
      </div>
    </>
  )
}
