import { useState } from 'react'
import { ArrowLeft, CheckCircle } from 'lucide-react'

const SPORT_OPTIONS = ['Football', 'Cricket', 'Pickleball', 'Badminton', 'Basketball', 'Tennis']

export default function OwnerPortal({ onBack }) {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({
    name: '',
    address: '',
    price: '',
    sports: [],
    minPlayers: '',
    maxPlayers: '',
    open: '',
    upiId: '',
    phone: '',
  })

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }))

  const toggleSport = (s) => {
    set('sports', form.sports.includes(s) ? form.sports.filter(x => x !== s) : [...form.sports, s])
  }

  const handleSubmit = () => {
    if (!form.name || !form.address || !form.price) return
    setSubmitted(true)
  }

  if (submitted) {
    return (
      <>
        <header className="topbar">
          <button className="back-btn" onClick={onBack} aria-label="Go back"><ArrowLeft size={20} /></button>
          <span className="topbar-title">Turf registered</span>
        </header>
        <div className="success-icon">
          <CheckCircle size={40} color="var(--success)" aria-hidden="true" />
        </div>
        <div className="success-title">Turf listed!</div>
        <div className="success-sub">
          <strong>{form.name}</strong> has been submitted for review. Our team will verify and activate it within 24 hours.
        </div>
        <div className="cta-bar">
          <button className="cta-btn success-btn" onClick={onBack}>Back to home</button>
        </div>
      </>
    )
  }

  return (
    <>
      <header className="topbar">
        <button className="back-btn" onClick={onBack} aria-label="Go back"><ArrowLeft size={20} /></button>
        <span className="topbar-title">Register your turf</span>
      </header>

      <div className="owner-section">
        <h3>Basic info</h3>

        <div className="form-field">
          <label className="form-label" htmlFor="turf-name">Turf name *</label>
          <input id="turf-name" className="form-input" placeholder="e.g. Green Arena" value={form.name} onChange={e => set('name', e.target.value)} />
        </div>

        <div className="form-field">
          <label className="form-label" htmlFor="turf-addr">Full address *</label>
          <input id="turf-addr" className="form-input" placeholder="Area, City" value={form.address} onChange={e => set('address', e.target.value)} />
        </div>

        <div className="form-field">
          <label className="form-label" htmlFor="turf-phone">Contact number *</label>
          <input id="turf-phone" className="form-input" placeholder="10-digit mobile" value={form.phone} onChange={e => set('phone', e.target.value)} type="tel" />
        </div>
      </div>

      <div style={{ height: 1, background: 'var(--border)' }} />

      <div className="owner-section">
        <h3>Sports offered</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {SPORT_OPTIONS.map(s => (
            <button
              key={s}
              onClick={() => toggleSport(s)}
              style={{
                padding: '6px 14px',
                borderRadius: 20,
                border: `1.5px solid ${form.sports.includes(s) ? 'var(--accent-mid)' : 'var(--border-strong)'}`,
                background: form.sports.includes(s) ? 'var(--accent-light)' : 'var(--surface)',
                color: form.sports.includes(s) ? 'var(--accent-mid)' : 'var(--text-2)',
                fontSize: 13,
                fontWeight: 500,
                cursor: 'pointer',
              }}
              aria-pressed={form.sports.includes(s)}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div style={{ height: 1, background: 'var(--border)' }} />

      <div className="owner-section">
        <h3>Booking details</h3>

        <div className="form-field">
          <label className="form-label" htmlFor="turf-price">Price per hour (₹) *</label>
          <input id="turf-price" className="form-input" placeholder="e.g. 500" value={form.price} onChange={e => set('price', e.target.value)} type="number" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
          <div className="form-field">
            <label className="form-label" htmlFor="turf-min">Min players</label>
            <input id="turf-min" className="form-input" placeholder="e.g. 5" value={form.minPlayers} onChange={e => set('minPlayers', e.target.value)} type="number" />
          </div>
          <div className="form-field">
            <label className="form-label" htmlFor="turf-max">Max players</label>
            <input id="turf-max" className="form-input" placeholder="e.g. 22" value={form.maxPlayers} onChange={e => set('maxPlayers', e.target.value)} type="number" />
          </div>
        </div>

        <div className="form-field">
          <label className="form-label" htmlFor="turf-hours">Opening hours</label>
          <input id="turf-hours" className="form-input" placeholder="e.g. 6:00 AM – 11:00 PM" value={form.open} onChange={e => set('open', e.target.value)} />
        </div>
      </div>

      <div style={{ height: 1, background: 'var(--border)' }} />

      <div className="owner-section">
        <h3>Payment</h3>
        <div className="form-field">
          <label className="form-label" htmlFor="turf-upi">UPI ID</label>
          <input id="turf-upi" className="form-input" placeholder="yourturf@upi" value={form.upiId} onChange={e => set('upiId', e.target.value)} />
        </div>
      </div>

      <div style={{ height: 16 }} />
      <div className="cta-bar">
        <button
          className="cta-btn"
          onClick={handleSubmit}
          disabled={!form.name || !form.address || !form.price}
        >
          Submit for review
        </button>
      </div>
    </>
  )
}
