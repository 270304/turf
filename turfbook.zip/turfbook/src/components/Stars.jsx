export default function Stars({ rating, size = 12 }) {
  return (
    <div className="stars" aria-label={`${rating} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map(i => (
        <span key={i} className={`star${i > Math.round(rating) ? ' empty' : ''}`} style={{ fontSize: size }}>★</span>
      ))}
    </div>
  )
}
