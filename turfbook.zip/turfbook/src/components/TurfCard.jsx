import { MapPin } from 'lucide-react'
import Stars from './Stars.jsx'

export default function TurfCard({ turf, onClick }) {
  return (
    <div className="turf-card" onClick={() => onClick(turf)} role="button" tabIndex={0}
      onKeyDown={e => e.key === 'Enter' && onClick(turf)}
      aria-label={`View ${turf.name}`}>
      <div className="turf-img" style={{ background: turf.color }}>
        <span role="img" aria-hidden="true">{turf.emoji}</span>
        <div className="turf-badges">
          <span className="badge badge-open">Open</span>
          <span className="badge badge-dist">{turf.dist} km</span>
        </div>
      </div>
      <div className="turf-body">
        <div className="turf-name">{turf.name}</div>
        <div className="turf-meta">
          <span className="turf-meta-item">
            <MapPin size={11} aria-hidden="true" />
            {turf.address}
          </span>
          <span className="turf-meta-item">
            ★ {turf.rating} ({turf.reviewCount})
          </span>
        </div>
        <div className="sport-tags">
          {turf.sports.map(s => <span key={s} className="sport-tag">{s}</span>)}
        </div>
        <div className="turf-footer">
          <div className="turf-price">₹{turf.price} <small>/ hr</small></div>
          <button className="btn-book" onClick={e => { e.stopPropagation(); onClick(turf) }}>
            Book now
          </button>
        </div>
      </div>
    </div>
  )
}
