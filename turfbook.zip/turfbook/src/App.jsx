import { useState } from 'react'
import { Home, Map, Calendar, User } from 'lucide-react'
import HomeScreen from './pages/HomeScreen.jsx'
import TurfDetail from './pages/TurfDetail.jsx'
import ConfirmBooking from './pages/ConfirmBooking.jsx'
import SuccessScreen from './pages/SuccessScreen.jsx'
import MyBookings from './pages/MyBookings.jsx'
import ExploreScreen from './pages/ExploreScreen.jsx'
import ProfileScreen from './pages/ProfileScreen.jsx'
import OwnerPortal from './pages/OwnerPortal.jsx'

const NAV = [
  { id: 'home',     label: 'Home',     Icon: Home },
  { id: 'explore',  label: 'Explore',  Icon: Map },
  { id: 'bookings', label: 'Bookings', Icon: Calendar },
  { id: 'profile',  label: 'Profile',  Icon: User },
]

export default function App() {
  const [tab, setTab] = useState('home')
  const [screen, setScreen] = useState('home') // home | detail | confirm | success | owner
  const [selectedTurf, setSelectedTurf] = useState(null)
  const [bookingData, setBookingData] = useState(null)
  const [myBookings, setMyBookings] = useState([])

  const goTo = (s) => setScreen(s)

  const openTurf = (turf) => {
    setSelectedTurf(turf)
    setScreen('detail')
  }

  const goToConfirm = (data) => {
    setBookingData({ ...data, turf: selectedTurf })
    setScreen('confirm')
  }

  const confirmBooking = () => {
    const booking = {
      ...bookingData,
      id: `TB${Math.floor(Math.random() * 90000 + 10000)}`,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    }
    setMyBookings(prev => [booking, ...prev])
    setScreen('success')
  }

  const mainContent = () => {
    if (screen === 'detail' && selectedTurf) {
      return <TurfDetail turf={selectedTurf} onBack={() => setScreen('home')} onContinue={goToConfirm} />
    }
    if (screen === 'confirm' && bookingData) {
      return <ConfirmBooking data={bookingData} onBack={() => setScreen('detail')} onConfirm={confirmBooking} />
    }
    if (screen === 'success') {
      return <SuccessScreen booking={myBookings[0]} onHome={() => { setScreen('home'); setTab('home') }} />
    }
    if (screen === 'owner') {
      return <OwnerPortal onBack={() => setScreen('home')} />
    }

    switch (tab) {
      case 'explore':  return <ExploreScreen onTurfClick={openTurf} />
      case 'bookings': return <MyBookings bookings={myBookings} />
      case 'profile':  return <ProfileScreen onOwnerPortal={() => setScreen('owner')} />
      default:         return <HomeScreen onTurfClick={openTurf} />
    }
  }

  const showNav = !['detail','confirm','success','owner'].includes(screen)

  return (
    <div className="app-shell">
      <div className="page-content">
        {mainContent()}
      </div>

      {showNav && (
        <nav className="bottom-nav" aria-label="Main navigation">
          {NAV.map(({ id, label, Icon }) => (
            <button
              key={id}
              className={`nav-item${tab === id && screen === 'home' || (tab === id && screen !== 'home' && screen !== 'detail' && screen !== 'confirm' && screen !== 'success') ? ' active' : tab === id && screen === 'home' ? ' active' : ''} ${tab === id ? ' active' : ''}`}
              onClick={() => { setTab(id); setScreen('home') }}
              aria-label={label}
              aria-current={tab === id ? 'page' : undefined}
            >
              <Icon size={22} strokeWidth={1.8} aria-hidden="true" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
      )}
    </div>
  )
}
