# TurfBook PWA

A mobile-first Progressive Web App to search, browse, and pre-book nearby sports turfs (Football, Cricket, Pickleball, Badminton, Basketball).

## Features
- 🔍 Search turfs by sport & location
- 📅 Live slot availability picker
- 👥 Member/player count selector (min–max per sport)
- 💳 UPI QR payment flow
- ✅ Booking confirmation with ID
- 🏟️ Owner portal — register & list your turf
- 📱 PWA — installable on Android & iOS

## Setup

```bash
npm install
npm run dev
```

Open http://localhost:5173

## Build for production

```bash
npm run build
npm run preview
```

## Deploy to Vercel

```bash
npm i -g vercel
vercel
```

## Environment variables (.env)

```
VITE_GOOGLE_MAPS_KEY=your_key_here   # for map integration
VITE_API_URL=https://your-backend.com
```

## Tech stack

| Layer       | Tool                        |
|-------------|----------------------------|
| Frontend    | React 18 + Vite             |
| PWA         | vite-plugin-pwa             |
| Icons       | lucide-react                |
| Routing     | react-router-dom            |
| Maps        | Google Maps / Leaflet.js    |
| Backend     | Node.js + Express (separate)|
| Database    | PostgreSQL                  |
| Auth        | Firebase Auth / JWT         |
| Hosting     | Vercel (frontend)           |

## Project structure

```
src/
├── data/
│   └── turfs.js          # Mock data (replace with API calls)
├── components/
│   ├── TurfCard.jsx
│   └── Stars.jsx
├── pages/
│   ├── HomeScreen.jsx
│   ├── TurfDetail.jsx
│   ├── ConfirmBooking.jsx
│   ├── SuccessScreen.jsx
│   ├── MyBookings.jsx
│   ├── ExploreScreen.jsx
│   ├── ProfileScreen.jsx
│   └── OwnerPortal.jsx
├── App.jsx
├── main.jsx
└── index.css
```

## Next steps

1. Connect to a real backend API (replace mock data in `src/data/turfs.js`)
2. Add Firebase Auth for user login
3. Integrate Google Maps in `ExploreScreen.jsx`
4. Connect Razorpay UPI API for real payments
5. Add push notifications for booking reminders
